import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { statusUpdates, contactById, me, contacts } from '../data/mockData';
import Avatar from '../components/Avatar';
import { CloseIcon, SendIcon, TrashIcon } from '../assets/icons/Icons';

export default function StatusViewer() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [slideIdx, setSlideIdx] = useState(0);
  const [reply, setReply] = useState('');
  const [progress, setProgress] = useState(0);

  const status = statusUpdates.find((s) => s.id === id);

  useEffect(() => { setSlideIdx(0); setProgress(0); }, [id]);

  useEffect(() => {
    if (!status) return;
    setProgress(0);
    const iv = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) return 100;
        return p + 100 / 60; // ~6s per slide
      });
    }, 100);
    return () => clearInterval(iv);
  }, [slideIdx, status]);

  if (!status) return <div className="flex-1 grid place-items-center text-slate-400">Status not found</div>;

  const contact = status.isMine ? me : contactById(status.contactId);
  const totalSlides = status.slides.length;
  const slide = status.slides[slideIdx];

  const goNext = () => {
    if (slideIdx < totalSlides - 1) setSlideIdx((i) => i + 1);
    else navigate('/status');
  };
  const goPrev = () => { if (slideIdx > 0) setSlideIdx((i) => i - 1); };

  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-slate-900 relative h-full py-4">
      <div className="relative w-full max-w-sm h-full max-h-[640px] rounded-2xl overflow-hidden bg-black flex flex-col animate-popIn">
        <div className="absolute top-2 left-2 right-2 flex gap-1 z-20">
          {status.slides.map((_, i) => (
            <div key={i} className="flex-1 h-1 rounded-full bg-white/30 overflow-hidden">
              <div
                className="h-full bg-white transition-[width] duration-100 linear"
                style={{ width: `${i < slideIdx ? 100 : i === slideIdx ? progress : 0}%` }}
              />
            </div>
          ))}
        </div>

        <div className="absolute top-5 left-3 right-3 flex items-center gap-2.5 z-20">
          <Avatar src={contact.avatar} name={contact.name} size={34} />
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium truncate">{status.isMine ? `${contact.name} (Me)` : contact.name}</p>
            <p className="text-white/70 text-[11px]">{slide.time}</p>
          </div>
          {status.isMine && (
            <button className="text-white/80 hover:text-white" title="Delete status">
              <TrashIcon size={17} />
            </button>
          )}
          <button onClick={() => navigate('/status')} className="text-white/80 hover:text-white">
            <CloseIcon size={20} />
          </button>
        </div>

        <img src={slide.image} alt="status" className="w-full h-full object-cover" />

        {/* tap zones */}
        <button className="absolute left-0 top-0 w-1/3 h-full" onClick={goPrev} aria-label="Previous" />
        <button className="absolute right-0 top-0 w-1/3 h-full" onClick={goNext} aria-label="Next" />

        {status.isMine ? (
          <div className="absolute bottom-3 left-0 right-0 flex justify-center">
            <span className="text-white/80 text-xs bg-black/30 rounded-full px-3 py-1">
              {contacts.slice(0, 3).length} viewed
            </span>
          </div>
        ) : (
          <div className="absolute bottom-3 left-3 right-3 flex items-center gap-2 z-20">
            <input
              value={reply}
              onChange={(e) => setReply(e.target.value)}
              placeholder={`Reply to ${contact.name}`}
              className="flex-1 bg-white/10 border border-white/30 rounded-full px-4 py-2 text-sm text-white placeholder:text-white/60 outline-none backdrop-blur-sm"
            />
            <button
              onClick={() => setReply('')}
              className="w-10 h-10 rounded-full bg-brand-500 grid place-items-center text-white shrink-0"
            >
              <SendIcon size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
