import { useState } from 'react';
import { Outlet, useNavigate, useParams } from 'react-router-dom';
import { statusUpdates, contactById, me } from '../data/mockData';
import Avatar from '../components/Avatar';
import EmptyState from '../components/EmptyState';
import { PlusIcon } from '../assets/icons/Icons';

export default function StatusPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const [viewedIds, setViewedIds] = useState(statusUpdates.filter((s) => s.viewed).map((s) => s.id));

  const mine = statusUpdates.filter((s) => s.isMine);
  const notSeen = statusUpdates.filter((s) => !s.isMine && !viewedIds.includes(s.id));
  const seen = statusUpdates.filter((s) => !s.isMine && viewedIds.includes(s.id));

  const openStatus = (statusId) => {
    setViewedIds((prev) => (prev.includes(statusId) ? prev : [...prev, statusId]));
    navigate(`/status/${statusId}`);
  };

  return (
    <div className="flex flex-1 min-w-0 h-full">
      <div className={`w-full md:w-[360px] shrink-0 flex flex-col border-r border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 ${id ? 'hidden md:flex' : 'flex'}`}>
        <div className="flex items-center justify-between px-4 pt-4 pb-3">
          <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">Updates</h1>
          <button className="w-9 h-9 grid place-items-center rounded-full text-brand-600 hover:bg-brand-50 dark:hover:bg-slate-800 dark:text-brand-400">
            <PlusIcon size={19} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-2 pb-2">
          {mine.map((s) => (
            <StatusRow key={s.id} s={s} active={id === s.id} label={me.name + ' (Me)'} onClick={() => openStatus(s.id)} isMine />
          ))}

          {notSeen.length > 0 && (
            <>
              <p className="px-2.5 pt-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Not seen</p>
              {notSeen.map((s) => <StatusRow key={s.id} s={s} active={id === s.id} onClick={() => openStatus(s.id)} />)}
            </>
          )}
          {seen.length > 0 && (
            <>
              <p className="px-2.5 pt-3 pb-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Seen</p>
              {seen.map((s) => <StatusRow key={s.id} s={s} active={id === s.id} onClick={() => openStatus(s.id)} seen />)}
            </>
          )}
        </div>
      </div>

      <div className={`flex-1 min-w-0 ${id ? 'flex' : 'hidden md:flex'}`}>
        {id ? <Outlet context={{ viewedIds, setViewedIds }} /> : <EmptyState hint="Click on an update to view" />}
      </div>
    </div>
  );
}

function StatusRow({ s, active, onClick, label, isMine, seen }) {
  const contact = isMine ? me : contactById(s.contactId);
  if (!contact) return null;
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left transition-colors ${
        active ? 'bg-brand-500 text-white' : 'hover:bg-slate-100 dark:hover:bg-slate-800/70'
      }`}
    >
      <div className={`p-[2px] rounded-full ${seen ? 'bg-slate-300 dark:bg-slate-600' : 'bg-gradient-to-tr from-brand-400 to-emerald-400'}`}>
        <Avatar src={contact.avatar} name={contact.name} size={44} className="ring-2 ring-white dark:ring-slate-900" />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`font-medium truncate text-[14.5px] ${active ? 'text-white' : 'text-slate-800 dark:text-slate-100'}`}>{label || contact.name}</p>
        <p className={`text-[12px] truncate ${active ? 'text-white/80' : 'text-slate-400'}`}>{s.slides[0].time}</p>
      </div>
    </button>
  );
}
